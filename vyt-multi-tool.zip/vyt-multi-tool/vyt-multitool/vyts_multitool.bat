@echo off
python vyts_multitool.py
pause
