
@echo off
cd /d %~dp0
python VYTOOL.py -u https://example.com -r 10 --slow
pause
