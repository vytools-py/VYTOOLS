ONLY USE ON YOUR WEBSITES WITH FULL PERMISSION OTHERWISE LEGAL  ACTIONS WILL HAPPEN.!!

HOW TO USE!!!! (for eds)

Python Method:

get the location of this folder "VYTOOL" mine is: C:\Users\CFLOL\Downloads\VYTOOL but
urs could be somewhere else

press windows + r on ur keyboard and type cmd then run it

type "cd C:\Users\CFLOL\Downloads\VYTOOL" but replace "C:\Users\CFLOL\Downloads\VYTOOL"
with what ever ur file location is 

then copy and paste into cmd 
"python VYTOOL.py -u https://yourdomain.com -r 10000 --fast" and it should work.
obviously replace yourdomain.com with the website ur attacking


.Bat Method (easier):

Right click VYTOOL.bat and click edit, then similar to the steps above change yourdomain 
to the website ur attacking
-------------------------------------------------------------------------------------------------------------------------------------------------
!!IMPORTANT!!: run this into ur cmd: pip install colorama and have the latest python installed. :!!IMPORTANT!!
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


EXTRA STUFF: 

yes this is skidded asf credits to: fsociety#1135 on revolt

follow my tiktok: display name usually vytlz current username is lqvrrsxd.
discord  is also currently :lqvrrs if u need help.



 ██▒   █▓██   ██▄▄▄█████▓▒█████  ▒█████  ██▓    
▓██░   █▒▒██  ██▓  ██▒ ▓▒██▒  ██▒██▒  ██▓██▒    
 ▓██  █▒░ ▒██ ██▒ ▓██░ ▒▒██░  ██▒██░  ██▒██░    
  ▒██ █░░ ░ ▐██▓░ ▓██▓ ░▒██   ██▒██   ██▒██░    
   ▒▀█░   ░ ██▒▓░ ▒██▒ ░░ ████▓▒░ ████▓▒░██████▒
   ░ ▐░    ██▒▒▒  ▒ ░░  ░ ▒░▒░▒░░ ▒░▒░▒░░ ▒░▓  ░
   ░ ░░  ▓██ ░▒░    ░     ░ ▒ ▒░  ░ ▒ ▒░░ ░ ▒  ░
     ░░  ▒ ▒ ░░   ░     ░ ░ ░ ▒ ░ ░ ░ ▒   ░ ░   
      ░  ░ ░                ░ ░     ░ ░     ░  ░
     ░   ░ ░                                    